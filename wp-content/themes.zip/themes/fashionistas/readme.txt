Fashionistas WordPress theme, Copyright (C) 2013 aThemes
Fashionistas WordPress theme is licensed under the GNU GPL v3.0

FOOTER LINK

You can remove the footer link if you like but we would appreciate your support for our work by retaining it.

CREDITS

Underscores (_s) - Base Theme
URL: http://underscores.me/
License: GNU GPL
Copyright: Automattic, automattic.com

Bootstrap - Base CSS
URL: http://twitter.github.io/bootstrap/
License: Apache License v2.0
Copyright:  Mark Otto (@mdo) & Jacob (@fat)

Font Awesome - Icon Fonts
URL: http://fortawesome.github.com/Font-Awesome/
License: SIL OFL 1.1
Copyright: Dave Gandy (@davegandy)

Entypo - Icon Fonts
URL: http://www.entypo.com/
License: SIL OFL 1.1
Copyright: Daniel Bruce (@danielbruce_)

Oswald - Font
URL: http://www.google.com/fonts/specimen/Oswald
License: SIL OFL 1.1
Copyright: Vernon Adams, https://plus.google.com/107807505287232434305/about

Superfish - Dropdown menu jQuery plugin.
URL: http://users.tpg.com.au/j_birch/plugins/superfish/
License: MIT and GPL
Copyright: Joel Birch, https://github.com/joeldbirch